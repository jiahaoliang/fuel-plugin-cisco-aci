===============================
group-based-policy-ui
===============================

Horizon modules for Group Based Policy

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/group-based-policy-ui
* Source: http://git.openstack.org/cgit/stackforge/group-based-policy-ui
* Bugs: http://bugs.launchpad.net/group-based-policy-ui

Features
--------

* TODO