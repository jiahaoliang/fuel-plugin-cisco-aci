This is the client API library for Group Based Policy.
