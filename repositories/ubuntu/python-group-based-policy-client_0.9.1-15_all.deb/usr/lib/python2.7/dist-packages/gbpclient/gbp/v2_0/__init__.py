from neutronclient.neutron import v2_0 as neutronV2_0

_get_resource_plural = neutronV2_0._get_resource_plural
