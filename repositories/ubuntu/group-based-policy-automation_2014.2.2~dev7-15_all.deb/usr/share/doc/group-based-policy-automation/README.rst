===============================
group-based-policy-automation
===============================

Group Based Policy Automation

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/group-based-policy-automation
* Source: http://git.openstack.org/cgit/stackforge/group-based-policy-automation
* Bugs: http://bugs.launchpad.net/group-based-policy-automation

Features
--------

* TODO